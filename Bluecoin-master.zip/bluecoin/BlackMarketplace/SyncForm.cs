﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackMarketplace
{
    public partial class SyncForm : Form
    {
        public SyncForm()
        {
            InitializeComponent();
        }

        private void Download(string url, string fname)
        {
            FileDownloader fd = new FileDownloader(url, fname);
            while (!fd.Finished)
            {
                progress.Text = "Downloading: " + fname + " / " + fd.DownloadedBytes + "b";
                Application.DoEvents();
            }
        }
        private void sync_Click(object sender, EventArgs e)
        {
            Config.WriteConfValue("KeysTsvUrl", keysTsv.Text);
            Download(keysTsv.Text, Path.Combine(Config.DataFolder, "keys.tsv"));
            this.DialogResult = DialogResult.OK;
        }

        private void SyncForm_Load(object sender, EventArgs e)
        {
            keysTsv.Text = Config.GetConfValue("KeyTsvUrl");
        }
    }
}
