﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BlackMarketplace
{
    public class FileDownloader
    {
        public bool Finished;
        public long DownloadedBytes;
        public long TotalBytes;
        public double Percentage;
        public FileDownloader(string url, string filename)
        {
            this.download(url, filename);
        }
        private void download(string url, string filename)
        {
            McClient wc = new McClient();

            // Make the request identical to minecraft.
            // How you gonna block me now?

            wc.Headers.Add("Accept", "*/*");
            wc.Headers.Add("User-Agent", PlayFab.CPP_REST_VERSION);
            wc.Headers.Add("Accept-Language", "en-US");
            wc.Headers.Add("Accept-Encoding", "gzip, deflate, br");

            wc.DownloadProgressChanged += Wc_DownloadProgressChanged;
            wc.DownloadFileCompleted += Wc_DownloadFileCompleted;
            wc.DownloadFileAsync(new Uri(url), filename);
        }

        private void Wc_DownloadFileCompleted(object? sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            Finished = true;
        }

        private void Wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            DownloadedBytes = e.BytesReceived;
            TotalBytes = e.TotalBytesToReceive;
            Percentage = e.ProgressPercentage;
        }

    }
}
