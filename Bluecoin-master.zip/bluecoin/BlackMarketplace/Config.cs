﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackMarketplace
{
    internal class Config
    {
        public static string DataFolder = Path.Combine(Environment.GetEnvironmentVariable("APPDATA"), "BlackMarketplace");
        public static string ConfigFile = Path.Combine(DataFolder, "noire.conf");

        private static void initConfig()
        {
            Directory.CreateDirectory(DataFolder);

            File.WriteAllLines(ConfigFile, new string[] { "KeyTsvUrl:https://thepillagerbay.org/DOWNLOAD_EVERYTHING.php?fmt=KTSV",
                                                          "KeyUploadUrl:https://thepillagerbay.org/mc/submitKeys.php",
                                                          "CppRestSdkVer:cpprestsdk/2.9.0",
                                                          "PlayfabSdkVer:XPlatCppSdk-3.6.190304",
                                                          "TitleSecret:S8RS53ZEIGMYTYG856U3U19AORWXQXF41J7FT3X9YCWAC7I35X",
                                                          "TitleId:20CA2"});
        }

        private static void replaceConfValue(string key, string newval)
        {
            if (!File.Exists(ConfigFile))
                initConfig();

            string[] keyValuePairs = File.ReadAllLines(ConfigFile);
            for(int i = 0; i < keyValuePairs.Length; i++)
            {
                string[] kvp = keyValuePairs[i].Split(':');
                if (kvp[0] == key)
                    keyValuePairs[i] = key + ":" + newval;
            }

            File.WriteAllLines(ConfigFile, keyValuePairs);
        }

        public static string GetConfValue(string key)
        {
            if (!File.Exists(ConfigFile))
                initConfig();

            string[] keyValuePairs = File.ReadAllLines(ConfigFile);
            foreach(string keyValuePair in keyValuePairs)
            {
                string[] kvp = keyValuePair.Split(':');
                if (kvp[0] == key)
                    return String.Join(':', kvp.Skip(1).ToArray());
            }

            return null;
        }
        public static void WriteConfValue(string key, string value)
        {
            if (!File.Exists(ConfigFile))
                initConfig();
            string curConfValue = GetConfValue(key);
            
            if (curConfValue == value)
                return;

            if (curConfValue != null)
                replaceConfValue(key, value);
            else
                File.AppendAllLines(ConfigFile, new string[] { key + ":" + value });
        }

    }
}
