Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: thepillagerbay.org

The information we received was the following:

Reporter: Anonymous

Reported URLs:

        http://thepillagerbay.org

Original Work: The site was built to provide access to Marketplace content owned by Mojang AB or partners.  Minecraft Gameplay & Imagery: Reg Number: TX 8-192-097 - https://www.minecraft.net
The material uses Mojang AB's well-known trademarks and copyrights, without authorization, infringing upon Mojang's intellectual property rights.

The site looks like a typical torrent index, but if reviewed you will see it is specific and built around illegally decrypting content on the fly.  The site should be removed for copyright infringement.
Comments:


We have forwarded this complaint to your hosting provider.
Thanks,
The Cloudflare Team
