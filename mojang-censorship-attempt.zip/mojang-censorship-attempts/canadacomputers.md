Hello,

Cloudflare received a DMCA copyright infringement complaint regarding thepillagerbay.org

Cloudflare offers network service solutions including pass-through security services, a content distribution network (CDN), and registrar services. Due to the pass-through nature of our services, our IP addresses appear in WHOIS and DNS records for websites using Cloudflare, and Cloudflare cannot remove material from the Internet that is hosted by others.

The actual host for thepillagerbay.org are the following IP addresses. REDACTED. Using the following command, you can confirm the site in question is hosted at that IP address: curl -v -H "Host: thepillagerbay.org" REDACTED/

Below is the information we received:

Reporter's Name: REDACTED     
Copyright Holder's Name: CanadaWebDeveloper     
Reporter's Email Address: legal@canadawebdeveloper.ca           
Reporter's Title: DMCA takedown notice            
Reporter's Company Name: PricewaterhouseCoopers International Limited              
Reporter's Telephone Number: REDACTED           
Reporter's Address: REDACTED           

Reported URLs:

    https://thepillagerbay.org/description.php?id=f40a2e46-ddbb-4184-95c2-1a9b62286daf
    https://thepillagerbay.org/description.php?id=3b5c6d66-254c-45ac-9a95-d5a752682c5c
    https://thepillagerbay.org/description.php?id=87a66e56-90ef-444f-90de-ee99668900c3
    https://thepillagerbay.org/description.php?id=c8d616aa-b311-4dfd-818c-b589e400641c
    https://thepillagerbay.org/description.php?id=dccd6081-5633-4b26-a1e6-7fa18e88517c
    https://thepillagerbay.org/description.php?id=fb774e81-bb13-4e92-a945-e1c33ebe34e8
    https://thepillagerbay.org/search.php?q=&cat=0
    https://thepillagerbay.org/description.php?id=b7c59e14-df5f-40fb-8a1d-b0744ba4498e
    https://thepillagerbay.org/description.php?id=eb00921a-cbf5-40c0-a247-b7cbdaa3cf98
    https://thepillagerbay.org/description.php?id=19dc28bc-fb15-43f3-9a56-cf44b1514059
    https://thepillagerbay.org/description.php?id=949296ea-2341-42cd-a837-d209c1b713f8

Original Work: To whom it may concern:
My name is REDACTED from PricewaterhouseCoopers International Limited, I am contacting you to day Feb 18 2022 in behalf of tour client Canada Web Developer LLC for the purposes of removing web content that infringes on our clients copyright
per the Digital Millennium Copyright Act (“DMCA”). This notice constitutes an official
notification under Section 512(c) of the DMCA.
Under that statute, you are required, as a service provider, to remove or disable
access to the infringing materials specified below upon receipt of this notice. Under
the safe harbor provision of the DMCA, you are given immunity from liability for
hosting the infringing content, provided that you quickly rectify and investigate the
copyright infringement. Failure to do so can result in the loss of this statutory
immunity.
The content that is being infringed is digital products delivered by Microsoft Corporation Inc via Mojang AB at the “Minecraft Marketplace” Minecraft Marketplace https://www.minecraft.net/marketplace

The infringing copy of this content is located at
    https://thepillagerbay.org/search.php?q=category:1
    https://thepillagerbay.org/search.php?q=category:2 https://thepillagerbay.org/search.php?q=category:3
    https://thepillagerbay.org/search.php?q=category:4


I have a good faith belief that the use of the copyrighted materials described above
on the allegedly infringing web pages is not authorized by our client the copyright owner, its
agent or the law. Under penalty of perjury I certify that the information contained in
this notification is both true and accurate, and that [I am the owner or I have the
authority to act on behalf of the owner] of the copyright(s) involved.
For further inquiry, I may be contacted at the above address, by phone or by email.
Sincerely,

Comments:

Please address this issue with your customer.

Regards,
Cloudflare Trust & Safety