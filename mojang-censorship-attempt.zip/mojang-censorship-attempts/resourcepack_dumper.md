Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: cbps.xyz

The information we received was the following:

Reporter: Anonymous

Reported URLs:

        https://git.cbps.xyz/olebeck/bedrock-server-resourcepack-dumper

Original Work: http://minecraft.net is the original work being manipulated through the site.

The tool exploits and uses secrets to decrypt proprietary information.  Their  tool is described as... Connect to an Minecraft Bedrock Edition server, download all the resourcepacks, their contentkeys and decrypt them
Comments:


We have forwarded this complaint to your hosting provider.
Thanks,
The Cloudflare Team