Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: cbps.xyz

The information we received was the following:

Reporter's Name: [REDACTED]

Copyright Holder's Name: [REDACTED]

Reporter's Email Address: [REDACTED]

Reporter's Company Name: [REDACTED]

Reporter's Address: [REDACTED]

Reported URLs:

        https://git.cbps.xyz/olebeck/bedrocktool

Original Work: Minecraft

Comments:

We have provided the name of your hosting provider to the reporter.

We have forwarded this complaint to your hosting provider.
Thanks,
The Cloudflare Team