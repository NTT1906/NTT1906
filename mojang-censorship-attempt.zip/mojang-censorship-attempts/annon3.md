Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: cbps.xyz

The information we received was the following:

Reporter: Anonymous

Reported URLs:

        https://git.cbps.xyz/ThePillagerBay/

Original Work: This git sit was created to host and share tools that go against the Minecraft Eula.  They are exposing and sharing methods of decryption and to proliferate normally protected content.  Based on secrets being exposed we would like the content and site removed.
Comments:


We have forwarded this complaint to your hosting provider.
Thanks,
The Cloudflare Team