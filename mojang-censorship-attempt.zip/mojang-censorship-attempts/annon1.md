Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: thepillagerbay.org

The information we received was the following:

Reporter: Anonymous

Reported URLs:

        https://thepillagerbay.org/search.php?q=minecraft&all=on&search=Pillager+Search&page=0&orderby=

Original Work: www.minecraft.net The material uses Mojang AB, wholly owned by Microsoft’s well-known trademarks and copyrights (Reg Number: TX 8-192-097), without authorization, infringing upon Microsoft’s intellectual property rights. The Minecraft game is protected by US copyright Reg. #TX 8-192-097, including the code itself, the game imagery, character assets, block textures, and artwork.