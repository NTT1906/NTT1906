# mojang-censorship-attempts

All times Mojang/Others tried to censor thepillagerbay.org, or related contents.

enjoy ! 
