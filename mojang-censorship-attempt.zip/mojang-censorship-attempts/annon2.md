Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: thepillagerbay.org

The information we received was the following:

Reporter: Anonymous

Reported URLs:

        http://thepillagerbay.org

Original Work: This entire site was built to share Minecraft marketplace content.  The only content linked to is items on our own CDN.  This site exploits the content via scripting to make sharing of the content possible.  We would like this site to be removed based on it is against our eula and promoting distribution of hacked or ill gotten content.
Comments:


We have forwarded this complaint to your hosting provider.
Thanks,
The Cloudflare Team