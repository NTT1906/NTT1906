Hello,

Cloudflare received a DMCA copyright infringement complaint regarding: thepillagerbay.org

The information we received was the following:

Reporter's Name: REDACTED
Copyright Holder's Name: Microsoft OSG
Reporter's Email Address: REDACTED
Reporter's Company Name: Microsoft - OSG
Reporter's Address: One Microsoft Way Redmond, WA, WA, US

Reported URLs:

        https://thepillagerbay.org/description.php?id=fd8a0c97-5de1-4a1d-962e-2fa598f2659d
        https://thepillagerbay.org/description.php?id=58d525a7-f93d-41a6-b1f3-c7887e2dad3d
        https://thepillagerbay.org/description.php?id=c955d644-8756-471a-8f3a-a7309297396f
        https://thepillagerbay.org/description.php?id=15412212-f877-4ae5-aaf4-1416803ad5bb
        https://thepillagerbay.org/description.php?id=352c2fdd-1261-4135-9b5c-5a4ed7a640f9
        https://thepillagerbay.org/description.php?id=eeda8413-2ffb-48e4-b622-5a21bc494482

Original Work: Minecraft

Comments:

We have provided the name of your hosting provider to the reporter.

We have forwarded this complaint to your hosting provider.
Thanks,
The Cloudflare Team