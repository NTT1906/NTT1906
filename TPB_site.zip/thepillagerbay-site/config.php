<?php
$dbname = 'tpb';
$dbuser = 'root';
$dbpass = '666c7daa531cfbc18a7f42cea7fbae284fc040f4';
$dbhost = '127.0.0.1';
?>